import { Component } from '@angular/core';

Component({
    selector: "stab",
    templateUrl: './stab.component.html',
    styleUrls: ['./stab.component.css']
})
export class StabComponent{

    
sarr=[{id:"1", name:"aaa", javamarks:"90",mathsmarks:"80",sciencemarks:"95" },
    {id:"2", name:"bbb", javamarks:"55",mathsmarks:"60",sciencemarks:"85" },
    {id:"3", name:"ccc", javamarks:"70",mathsmarks:"85",sciencemarks:"75" }];
    
}